package sample.Databases;

public class conf {
    protected String dbHost="localhost";
    protected String dbPort="3306";
    protected String dbUser="root";
    protected String dbPass="mysql";
    protected String dbName="farmdb";
}
