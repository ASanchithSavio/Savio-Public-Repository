package sample.model;



public class Cropprices {
    private int cropid;
    private String cropname;

    public int getCropid() {
        return cropid;
    }

    public void setCropid(int cropid) {
        this.cropid = cropid;
    }

    public String getCropname() {
        return cropname;
    }

    public void setCropname(String cropname) {
        this.cropname = cropname;
    }

    public String getCropprice() {
        return cropprice;
    }

    public void setCropprice(String cropprice) {
        this.cropprice = cropprice;
    }

    private String cropprice;


}
